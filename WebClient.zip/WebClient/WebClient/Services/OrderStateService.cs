﻿namespace WebClient.Services
{
    public class OrderStateService
    {
        public int? CurrentOrderId { get; set; }
    }
}
